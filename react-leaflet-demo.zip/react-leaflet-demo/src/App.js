import React from "react";
import { MapContainer,TileLayer , Marker, Popup} from 'react-leaflet';
import './App.css';

function App() {
  return (
    <MapContainer center={[37, -122]} zoom={55} scrollWheelZoom={true}>
      <TileLayer
    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
      />
    <Marker position={[37, -122]}>
      <Popup>I am a pop-up!</Popup>
    </Marker>
    </MapContainer>
  );
}

export default App;